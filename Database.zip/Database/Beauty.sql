Create Database AssigmentBeautyPara



Create Table BeautyProudcts(
ProductID int not null Constraint PK_BeautyProudcts PRIMARY Key (ProductID),
ProductName nvarchar (30) not null,
image varchar(50),
ProductDescription nvarchar (200) not null,
) 
drop table MemberReivew

Insert dbo.BeautyProducts
Values(1,'EtudeHouseLipstick','di.jpg','Good quality lipstcik with beautiful color' )

Insert dBo.BeautyProducts
Values(1,'Dior Lipstick','di.jpg','A collection of couture, satin-to-matte lipsticks with highly pigmented finishes with lasting comfort 
and 16 hours of comfort')

Insert into dbo.BeautyProducts
Values(3,'Channel2BFoundation','Chanel2BFoundations.jpg','The best foundations for aging skin, improve complexion, and provide long lasting intense hydration')


Insert dBo.BeautyProducts
Values(4,'MAC Matte Lipstick Marrakesh','maclipstick.jpg','A creamy rich Lipstick formula with high colour payoff in a no-shine matte finish. 
�Marrakesh: Intense orange brown (Matte)')

Insert dBo.BeautyProducts
Values(5,'Anastasia Beverly Hills ','122.jpg','A full-pigment lip color with a velvety-smooth ultra-matte finish and comfortable wearability.'

)

Insert dBo.BeautyProducts
Values(4,'MAC Matte Lipstick Marrakesh','maclipstick.jpg','A creamy rich Lipstick formula with high colour payoff in a no-shine matte finish. 
�Marrakesh: Intense orange brown (Matte)')



DELETE FROM dbo.BeautyProducts WHERE ProductID=4;

select * from BeautyProducts
The BrowGal Instatint Tinted Brow Gel 

Create Table MemberReivew(

ReviewID varchar(10) primary key,
CustomerID nvarchar(128),
PrdouctID int,
SuggesstionText varchar(1000) not null, 
constraint FK_ProductID Foreign Key(PrdouctID) References BeautyProducts(ProductID),
constraint FK_CustomerID Foreign Key(CustomerID) References dbo.AspNetUsers(Id),

)

Select*from MemberReivew


DELETE FROM MemberReivew  WHERE ReviewID=12;